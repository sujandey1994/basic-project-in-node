var commonModel = require('../models/commonModel')    

exports.index = async function(req, res) {
	var countries = await commonModel.getCountries({});
	// console.log(countries);
	res.render('front/template/default', {
		countries: countries,
		pageName: 'home/index',
		pageTitle: 'Home'
	})
};