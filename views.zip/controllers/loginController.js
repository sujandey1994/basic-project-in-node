var loginModel = require('../models/loginModel')    

exports.index = async function(req, res) {
	res.render('front/template/default', {
		pageName: 'login/index',
		pageTitle: 'Login',
		jsFiles:['login']
	})
};

exports.sendLogin = async function(req, res) {
	var login = await loginModel.sendLogin(req);
	console.log(login);
	res.status(200).send({'status':1})
	// res.render('front/template/default', {
	// 	countries: countries,
	// 	pageName: 'home/index'
	// })
};