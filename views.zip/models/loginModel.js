var connection = require('../config/database');

exports.getLogin = async function (query) {

	return new Promise(function(resolve, reject) {
		var sqli = 'select * FROM countries';
		connection.query(sqli,function(err, result, fields){
			if (err){
				return err
			} else{
				resolve(result);
			}
		});
	});

}

exports.sendLogin = async function (query) {
	console.log(query);
	// return new Promise(function(resolve, reject) {
	// 	var sqli = 'select * FROM countries';
	// 	connection.query(sqli,function(err, result, fields){
	// 		if (err){
	// 			return err
	// 		} else{
	// 			resolve(result);
	// 		}
	// 	});
	// });

}