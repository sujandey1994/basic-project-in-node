var connection = require('../config/database');

exports.getCountries = async function (query, page, limit) {

	return new Promise(function(resolve, reject) {

		var sqli = 'select * FROM countries';
		connection.query(sqli,function(err, result, fields){
			if (err){
				return err
			} else{
				resolve(result);
			}
		});

	});

}