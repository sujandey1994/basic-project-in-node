var express = require('express');
var router = express.Router();

var homeController = require('../controllers/homeController')
var loginController = require('../controllers/loginController')

router.get('/', homeController.index);
router.get('/login', loginController.index);
router.post('/send-login', loginController.sendLogin);

module.exports = router;